Upload the gate.php file to the web server and set the file permissions

Change the web server address localhost in file main.cpp


