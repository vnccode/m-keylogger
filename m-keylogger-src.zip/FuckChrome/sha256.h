#include <Windows.h>

#define SHA256_DIGEST_LENGTH	32

#ifdef _MSC_VER
#ifndef uint8_t
typedef unsigned __int8 uint8_t;
#endif
#ifndef uint32_t
typedef unsigned __int32 uint32_t;
#endif
#ifndef uint64_t
typedef __int64 int64_t;
typedef unsigned __int64 uint64_t;
#endif
#else
#include <stdint.h>
#endif

#ifdef __cplusplus
extern "C"
{
#endif

	typedef struct {
		unsigned __int32 buf[16];
		unsigned __int32 hash[8];
		unsigned __int32 len[2];
	} sha256_context2;

	void sha256_init(sha256_context2 *);
	void sha256_hash(sha256_context2 *, uint8_t * /* data */, uint32_t /* len */);
	void sha256_done(sha256_context2 *, uint8_t * /* hash */);

#ifdef __cplusplus
}
#endif
